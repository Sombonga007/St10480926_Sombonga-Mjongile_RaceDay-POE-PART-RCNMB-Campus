﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

public class AuthService
{
    private readonly RaceDayContext db;
    private readonly IPasswordHasher<User> hasher;

    public AuthService(RaceDayContext db, IPasswordHasher<User> hasher)
    {
        this.db = db;
        this.hasher = hasher;
    }
    public async Task<(User? User, string? Error)> Register(
        RegisterRequest request)
    {
        var role = request.Role.Trim();

        if (role is not ("Organiser" or "Participant"))
            return (null, "Role must be Organiser or Participant.");

        var email = request.Email.Trim().ToLowerInvariant();

        if (await db.Users.AnyAsync(x => x.Email == email))
            return (null, "An account with this email already exists.");

        var user = new User
        {
            FullName = request.FullName.Trim(),
            Email = email,
            Role = role
        };

        user.PasswordHash =
            hasher.HashPassword(user, request.Password);

        db.Users.Add(user);
        await db.SaveChangesAsync();

        return (user, null);
    }

    public async Task<User?> Login(LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();

        var user = await db.Users
            .SingleOrDefaultAsync(x => x.Email == email);

        if (user is null)
            return null;

        var result = hasher.VerifyHashedPassword(
            user,
            user.PasswordHash,
            request.Password);

        return result == PasswordVerificationResult.Failed
            ? null
            : user;
    }
}
