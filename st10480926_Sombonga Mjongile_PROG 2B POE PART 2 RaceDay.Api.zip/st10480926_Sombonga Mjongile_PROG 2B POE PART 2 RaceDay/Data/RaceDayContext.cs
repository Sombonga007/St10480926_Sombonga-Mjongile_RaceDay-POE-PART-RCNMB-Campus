﻿
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

public class RaceDayContext(
    DbContextOptions<RaceDayContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<EventType> EventTypes => Set<EventType>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<Result> Results => Set<Result>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>().HasIndex(x => x.Email).IsUnique();

        b.Entity<User>()
            .Property(x => x.Role)
            .HasDefaultValue("Participant");

        b.Entity<EventType>().HasIndex(x => x.Name).IsUnique();

        b.Entity<Event>()
            .Property(x => x.Distance)
            .HasPrecision(8, 2);

        b.Entity<Event>()
            .HasOne(x => x.Organiser)
            .WithMany(x => x.OrganisedEvents)
            .HasForeignKey(x => x.OrganiserId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Event>()
            .HasOne(x => x.EventType)
            .WithMany(x => x.Events)
            .HasForeignKey(x => x.EventTypeId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Category>()
            .HasOne(x => x.Event)
            .WithMany(x => x.Categories)
            .HasForeignKey(x => x.EventId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<Enrolment>()
            .HasIndex(x => new { x.UserId, x.EventId })
            .IsUnique();

        b.Entity<Enrolment>()
            .HasOne(x => x.Participant)
            .WithMany(x => x.Enrolments)
            .HasForeignKey(x => x.UserId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Enrolment>()
            .HasOne(x => x.Event)
            .WithMany(x => x.Enrolments)
            .HasForeignKey(x => x.EventId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Enrolment>()
            .HasOne(x => x.Category)
            .WithMany(x => x.Enrolments)
            .HasForeignKey(x => x.CategoryId)
            .OnDelete(DeleteBehavior.Restrict);

        b.Entity<Enrolment>()
            .HasOne(x => x.Result)
            .WithOne(x => x.Enrolment)
            .HasForeignKey<Result>(x => x.EnrolmentId)
            .OnDelete(DeleteBehavior.Cascade);

        b.Entity<Result>()
            .HasIndex(x => x.EnrolmentId)
            .IsUnique();

        b.Entity<EventType>().HasData(
            new EventType { EventTypeId = 1, Name = "Run" },
            new EventType { EventTypeId = 2, Name = "Walk" },
            new EventType { EventTypeId = 3, Name = "Cycle" }
        );
    }
}
