﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[ApiController]
public abstract class ApiControllerBase : ControllerBase
{
    protected int? CurrentUserId =>
        HttpContext.Session.GetInt32("UserId");

    protected string? CurrentRole =>
        HttpContext.Session.GetString("Role");

    protected IActionResult? RequireLogin()
    {
        return CurrentUserId is null
            ? Unauthorized(new { message = "Please log in first." })
            : null;
    }

    protected IActionResult? RequireRole(string role)
    {
        var login = RequireLogin();

        if (login is not null)
        {
            return login;
        }

        return CurrentRole == role ? null : Forbid();
    }

    protected static object PublicUser(User u) => new
    {
        u.UserId,
        u.FullName,
        u.Email,
        u.Role,
        u.ProfilePictureUrl,
        u.CreatedAt
    };
}