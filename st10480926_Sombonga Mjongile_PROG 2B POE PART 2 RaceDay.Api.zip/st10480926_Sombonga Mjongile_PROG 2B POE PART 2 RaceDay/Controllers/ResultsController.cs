﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;

namespace RaceDay.Api.Controllers;

[Route("api/results")]
public class ResultsController(
    RaceDayContext db) : ApiControllerBase
{
    [HttpPost("enrolments/{enrolmentId:int}")]
    public async Task<IActionResult> Record(
        int enrolmentId, ResultRequest req)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var enrolment = await db.Enrolments
            .Include(x => x.Event)
            .Include(x => x.Result)
            .FirstOrDefaultAsync(
                x => x.EnrolmentId == enrolmentId);

        if (enrolment is null)
            return NotFound();

        if (enrolment.Event!.OrganiserId != CurrentUserId)
            return Forbid();

        if (enrolment.Result is not null)
        {
            return Conflict(new
            {
                message = "A result already exists for this enrolment."
            });
        }

        if (req.FinishTime < TimeSpan.Zero)
        {
            return BadRequest(new
            {
                message = "Finish time cannot be negative."
            });
        }

        var result = new Models.Result
        {
            EnrolmentId = enrolmentId,
            FinishTime = req.FinishTime,
            FinishingPosition = req.FinishingPosition
        };

        db.Results.Add(result);
        await db.SaveChangesAsync();

        return Created("/api/results/mine", result);
    }

    [HttpGet("mine")]
    public async Task<IActionResult> Mine()
    {
        var check = RequireRole("Participant");

        if (check is not null)
            return check;

        var results = await db.Results
            .AsNoTracking()
            .Include(x => x.Enrolment!)
                .ThenInclude(x => x.Event)
            .Include(x => x.Enrolment!)
                .ThenInclude(x => x.Category)
            .Where(x => x.Enrolment!.UserId == CurrentUserId)
            .Select(x => new
            {
                x.ResultId,
                x.FinishTime,
                x.FinishingPosition,
                x.RecordedAt,
                EventName = x.Enrolment!.Event!.EventName,
                EventDate = x.Enrolment.Event.EventDate,
                Category = x.Enrolment.Category!.CategoryName
            })
            .ToListAsync();

        return Ok(results);
    }
}