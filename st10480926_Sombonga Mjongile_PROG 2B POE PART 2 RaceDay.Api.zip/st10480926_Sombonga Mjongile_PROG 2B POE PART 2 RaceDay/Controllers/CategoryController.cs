﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api/categories")]
public class CategoriesController(
    RaceDayContext db) : ApiControllerBase
{
    [HttpGet]
    public async Task<IActionResult> All([FromQuery] int? eventId)
    {
        var query = db.Categories.AsNoTracking().AsQueryable();

        if (eventId.HasValue)
            query = query.Where(x => x.EventId == eventId.Value);

        var categories = await query
            .Select(x => new
            {
                x.CategoryId,
                x.EventId,
                x.CategoryName,
                x.Description
            })
            .ToListAsync();

        return Ok(categories);
    }

    [HttpPost("events/{eventId:int}")]
    public async Task<IActionResult> Create(
        int eventId, CategoryRequest req)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var ev = await db.Events.FindAsync(eventId);

        if (ev is null)
            return NotFound(new { message = "Event not found." });

        if (ev.OrganiserId != CurrentUserId)
            return Forbid();

        var category = new Category
        {
            EventId = eventId,
            CategoryName = req.CategoryName,
            Description = req.Description
        };

        db.Categories.Add(category);
        await db.SaveChangesAsync();

        return Created(
            "/api/categories?eventId=" + eventId,
            category);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(
        int id, CategoryRequest req)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var category = await db.Categories
            .Include(x => x.Event)
            .FirstOrDefaultAsync(x => x.CategoryId == id);

        if (category is null)
            return NotFound();

        if (category.Event!.OrganiserId != CurrentUserId)
            return Forbid();

        category.CategoryName = req.CategoryName;
        category.Description = req.Description;

        await db.SaveChangesAsync();

        return Ok(category);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        var category = await db.Categories
            .Include(x => x.Event)
            .FirstOrDefaultAsync(x => x.CategoryId == id);

        if (category is null)
            return NotFound();

        if (category.Event!.OrganiserId != CurrentUserId)
            return Forbid();

        db.Categories.Remove(category);
        await db.SaveChangesAsync();

        return NoContent();
    }
}