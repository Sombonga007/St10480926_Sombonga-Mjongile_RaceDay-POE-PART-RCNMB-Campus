﻿using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[Route("api/auth")]
public class AuthController(
    AuthService auth,
    RaceDayContext db) : ApiControllerBase
{
    [HttpPost("register")]
    public async Task<IActionResult> Register(RaceDay.Api.DTOs.RegisterRequest request)
    {
        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var (user, error) = await auth.Register(request);

        if (error is not null)
            return Conflict(new { message = error });

        return Created("/api/profile", PublicUser(user!));
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(RaceDay.Api.DTOs.LoginRequest request)
    {
        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var user = await auth.Login(request);

        if (user is null)
        {
            return Unauthorized(new
            {
                message = "Invalid email or password."
            });
        }

        HttpContext.Session.SetInt32("UserId", user.UserId);
        HttpContext.Session.SetString("Role", user.Role);

        return Ok(new
        {
            user = PublicUser(user),
            message = "Login successful."
        });
    }

    [HttpPost("logout")]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();

        return Ok(new { message = "Logged out." });
    }

    [HttpGet("session")]
    public async Task<IActionResult> SessionInfo()
    {
        var id = CurrentUserId;

        if (id is null)
            return Unauthorized();

        var user = await db.Users.FindAsync(id.Value);

        return user is null
            ? Unauthorized()
            : Ok(PublicUser(user));
    }
}