﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

[Route("api/events")]
public class EventsController(
    RaceDayContext db) : ApiControllerBase
{
    [HttpGet]
    public async Task<IActionResult> All()
    {
        var events = await db.Events
            .AsNoTracking()
            .Include(x => x.EventType)
            .Select(x => new
            {
                x.EventId,
                x.EventName,
                x.Description,
                x.EventDate,
                x.Location,
                x.Distance,
                EventType = x.EventType!.Name,
                x.OrganiserId,
                x.BannerImageUrl
            })
            .ToListAsync();

        return Ok(events);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var ev = await db.Events
            .AsNoTracking()
            .Include(x => x.EventType)
            .Include(x => x.Categories)
            .Where(x => x.EventId == id)
            .Select(x => new
            {
                x.EventId,
                x.EventName,
                x.Description,
                x.EventDate,
                x.Location,
                x.Distance,
                EventType = x.EventType!.Name,
                x.OrganiserId,
                x.BannerImageUrl,
                Categories = x.Categories.Select(c => new
                {
                    c.CategoryId,
                    c.CategoryName,
                    c.Description
                })
            })
            .SingleOrDefaultAsync();

        return ev is null ? NotFound() : Ok(ev);
    }

    [HttpPost]
    public async Task<IActionResult> Create(EventRequest req)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        if (!await db.EventTypes.AnyAsync(
            x => x.EventTypeId == req.EventTypeId))
        {
            return BadRequest(new { message = "Unknown event type." });
        }

        var ev = new Event
        {
            EventName = req.EventName,
            Description = req.Description,
            EventDate = req.EventDate,
            Location = req.Location,
            Distance = req.Distance,
            EventTypeId = req.EventTypeId,
            OrganiserId = CurrentUserId!.Value
        };

        db.Events.Add(ev);
        await db.SaveChangesAsync();

        return CreatedAtAction(
            nameof(Get),
            new { id = ev.EventId },
            ev);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, EventRequest req)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var ev = await db.Events.FindAsync(id);

        if (ev is null)
            return NotFound();

        if (ev.OrganiserId != CurrentUserId)
            return Forbid();

        if (!await db.EventTypes.AnyAsync(
            x => x.EventTypeId == req.EventTypeId))
        {
            return BadRequest(new { message = "Unknown event type." });
        }

        ev.EventName = req.EventName;
        ev.Description = req.Description;
        ev.EventDate = req.EventDate;
        ev.Location = req.Location;
        ev.Distance = req.Distance;
        ev.EventTypeId = req.EventTypeId;

        await db.SaveChangesAsync();

        return Ok(ev);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        var ev = await db.Events.FindAsync(id);

        if (ev is null)
            return NotFound();

        if (ev.OrganiserId != CurrentUserId)
            return Forbid();

        db.Events.Remove(ev);
        await db.SaveChangesAsync();

        return NoContent();
    }
}