﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;

namespace RaceDay.Api.Controllers;

[Route("api/enrolments")]
public class EnrolmentsController(
    RaceDayContext db) : ApiControllerBase
{
    [HttpPost]
    public async Task<IActionResult> Enrol(EnrolmentRequest req)
    {
        var check = RequireRole("Participant");

        if (check is not null)
            return check;

        if (!await db.Events.AnyAsync(
            x => x.EventId == req.EventId))
        {
            return NotFound(new { message = "Event not found." });
        }

        if (!await db.Categories.AnyAsync(
            x => x.CategoryId == req.CategoryId
                 && x.EventId == req.EventId))
        {
            return BadRequest(new
            {
                message = "Category does not belong to this event."
            });
        }

        if (await db.Enrolments.AnyAsync(
            x => x.UserId == CurrentUserId
                 && x.EventId == req.EventId))
        {
            return Conflict(new
            {
                message = "You have already entered this event."
            });
        }

        var enrolment = new Models.Enrolment
        {
            UserId = CurrentUserId!.Value,
            EventId = req.EventId,
            CategoryId = req.CategoryId
        };

        db.Enrolments.Add(enrolment);
        await db.SaveChangesAsync();

        return Created(
            "/api/enrolments/mine/" + enrolment.EnrolmentId,
            enrolment);
    }

    [HttpGet("mine")]
    public async Task<IActionResult> Mine()
    {
        var check = RequireRole("Participant");

        if (check is not null)
            return check;

        var enrolments = await db.Enrolments
            .AsNoTracking()
            .Where(x => x.UserId == CurrentUserId)
            .Include(x => x.Event)
            .Include(x => x.Category)
            .Select(x => new
            {
                x.EnrolmentId,
                x.Status,
                x.EnrolledAt,
                Event = new
                {
                    x.Event!.EventId,
                    x.Event.EventName,
                    x.Event.EventDate,
                    x.Event.Location
                },
                Category = x.Category!.CategoryName
            })
            .ToListAsync();

        return Ok(enrolments);
    }

    [HttpGet("events/{eventId:int}")]
    public async Task<IActionResult> ForEvent(int eventId)
    {
        var check = RequireRole("Organiser");

        if (check is not null)
            return check;

        var ev = await db.Events.FindAsync(eventId);

        if (ev is null)
            return NotFound();

        if (ev.OrganiserId != CurrentUserId)
            return Forbid();

        var enrolments = await db.Enrolments
            .AsNoTracking()
            .Where(x => x.EventId == eventId)
            .Include(x => x.Participant)
            .Include(x => x.Category)
            .Select(x => new
            {
                x.EnrolmentId,
                x.Status,
                x.EnrolledAt,
                Participant = new
                {
                    x.Participant!.UserId,
                    x.Participant.FullName,
                    x.Participant.Email
                },
                Category = x.Category!.CategoryName
            })
            .ToListAsync();

        return Ok(enrolments);
    }
}