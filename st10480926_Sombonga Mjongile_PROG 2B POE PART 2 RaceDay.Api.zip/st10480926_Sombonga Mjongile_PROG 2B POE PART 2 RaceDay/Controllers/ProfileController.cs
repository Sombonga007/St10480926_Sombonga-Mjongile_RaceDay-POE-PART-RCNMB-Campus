﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;

namespace RaceDay.Api.Controllers;

[Route("api/profile")]
public class ProfileController(
    RaceDayContext db) : ApiControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var check = RequireLogin();

        if (check is not null)
            return check;

        var user = await db.Users.FindAsync(CurrentUserId!.Value);

        return user is null
            ? NotFound()
            : Ok(PublicUser(user));
    }

    [HttpPut]
    public async Task<IActionResult> Update(UpdateProfileRequest req)
    {
        var check = RequireLogin();

        if (check is not null)
            return check;

        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var user = await db.Users.FindAsync(CurrentUserId!.Value);

        if (user is null)
            return NotFound();

        var email = req.Email.Trim().ToLowerInvariant();

        if (await db.Users.AnyAsync(
            x => x.Email == email && x.UserId != user.UserId))
        {
            return Conflict(new
            {
                message = "Email is already in use."
            });
        }

        user.FullName = req.FullName.Trim();
        user.Email = email;
        user.ProfilePictureUrl = req.ProfilePictureUrl;

        await db.SaveChangesAsync();

        return Ok(PublicUser(user));
    }
}