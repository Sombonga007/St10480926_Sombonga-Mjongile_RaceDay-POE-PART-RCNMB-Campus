
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// Register API controllers.
builder.Services.AddControllers();

// Register Swagger services.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Register the SQL Server database context.
builder.Services.AddDbContext<RaceDayContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("RaceDay")
        ?? throw new InvalidOperationException(
            "Connection string 'RaceDay' is missing.")));

// Configure server-side session storage.
builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.Cookie.Name = ".RaceDay.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.IdleTimeout = TimeSpan.FromMinutes(30);
});

// Register secure password hashing.
builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();

// Register the authentication service.
builder.Services.AddScoped<AuthService>();

var app = builder.Build();

// Enable Swagger while developing.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Session middleware must run before controllers use session data.
app.UseSession();

// Add a basic security response header.
app.Use(async (context, next) =>
{
    context.Response.Headers.TryAdd(
        "X-Content-Type-Options", "nosniff");

    await next();
});

// Map controller routes.
app.MapControllers();

// Provide a simple health check.
app.MapGet("/", () => Results.Ok(new
{
    name = "RaceDay API",
    status = "running",
    swagger = "/swagger"
}));

app.Run();

// Makes Program accessible to integration-test projects.
public partial class Program { }
