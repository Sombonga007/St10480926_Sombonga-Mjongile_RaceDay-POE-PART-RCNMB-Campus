using System;
using System.Collections.Generic;

namespace RaceDay.Api.DTOs;

public record UserResponse(
    int UserID,
    string FirstName,
    string LastName,
    string Email,
    string Role,
    string? ProfilePictureUrl);

public record EventResponse(
    int EventID,
    string EventName,
    string Description,
    DateTime EventDate,
    string Location,
    decimal Distance,
    string EventType,
    int OrganiserID,
    string? BannerImageUrl,
    IEnumerable<CategoryResponse>? Categories);

public record CategoryResponse(
    int CategoryID,
    string CategoryName,
    string? Description);

public record EnrolmentResponse(
    int EnrolmentID,
    int ParticipantID,
    int EventID,
    int CategoryID,
    string Status);

public record ResultResponse(
    int ResultID,
    int ParticipantID,
    int EventID,
    TimeSpan FinishTime,
    int FinishingPosition,
    int TotalFinishers);
