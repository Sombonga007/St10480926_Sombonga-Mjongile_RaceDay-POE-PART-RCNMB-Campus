﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs;

public record RegisterRequest(
    [Required, MaxLength(100)] string FullName,
    [Required, EmailAddress] string Email,
    [Required, MinLength(8)] string Password,
    [Required] string Role);

public record LoginRequest(
    [Required, EmailAddress] string Email,
    [Required] string Password);

public record UpdateProfileRequest(
    [Required, MaxLength(100)] string FullName,
    [Required, EmailAddress] string Email,
    string? ProfilePictureUrl);

public record EventRequest(
    [Required, MaxLength(150)] string EventName,
    [MaxLength(2000)] string Description,
    DateTime EventDate,
    [Required, MaxLength(200)] string Location,
    [Range(0.1, 1000)] decimal Distance,
    int EventTypeId);

public record CategoryRequest(
    [Required, MaxLength(100)] string CategoryName,
    string? Description);

public record EnrolmentRequest(
    int EventId,
    int CategoryId);

public record ResultRequest(
    TimeSpan FinishTime,
    [Range(1, int.MaxValue)] int FinishingPosition);
