﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models;

public class Event
{
    public int EventId { get; set; }

    [Required, MaxLength(150)]
    public string EventName { get; set; } = "";

    [MaxLength(2000)]
    public string Description { get; set; } = "";

    public DateTime EventDate { get; set; }

    [Required, MaxLength(200)]
    public string Location { get; set; } = "";

    [Range(0.1, 1000)]
    public decimal Distance { get; set; }

    public int EventTypeId { get; set; }

    public int OrganiserId { get; set; }

    [MaxLength(500)]
    public string? BannerImageUrl { get; set; }

    public User? Organiser { get; set; }

    public EventType? EventType { get; set; }

    public ICollection<Category> Categories { get; set; }
        = new List<Category>();

    public ICollection<Enrolment> Enrolments { get; set; }
        = new List<Enrolment>();
}