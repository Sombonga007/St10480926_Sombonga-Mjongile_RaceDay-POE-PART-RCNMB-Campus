﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models;

public class Category
{
    public int CategoryId { get; set; }

    public int EventId { get; set; }

    [Required, MaxLength(100)]
    public string CategoryName { get; set; } = "";

    [MaxLength(300)]
    public string? Description { get; set; }

    public Event? Event { get; set; }

    public ICollection<Enrolment> Enrolments { get; set; }
        = new List<Enrolment>();
}
