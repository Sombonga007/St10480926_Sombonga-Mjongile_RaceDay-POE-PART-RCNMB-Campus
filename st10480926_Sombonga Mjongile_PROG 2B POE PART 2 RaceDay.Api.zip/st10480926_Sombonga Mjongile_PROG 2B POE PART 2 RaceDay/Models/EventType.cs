﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.Models;

public class EventType
{
    public int EventTypeId { get; set; }

    [Required, MaxLength(20)]
    public string Name { get; set; } = "";

    public ICollection<Event> Events { get; set; }
        = new List<Event>();
}